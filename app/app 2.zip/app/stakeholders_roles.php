<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class stakeholders_roles extends Model
{
    //
    protected $table='stakeholders_roles';
}
