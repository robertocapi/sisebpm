<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class impotlx extends Model
{
    //
   
}
