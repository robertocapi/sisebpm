<?php

namespace impotlx\Http\Controllers;

use Illuminate\Http\Request;

class logincontroller extends Controller
{
    //
}
