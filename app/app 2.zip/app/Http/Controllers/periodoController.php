<?php

namespace impotlx\Http\Controllers;

use Illuminate\Http\Request;

class periodoController extends Controller
{
    //
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
               $bar = new alumnosController;
        $periodosr = \impotlx\periodos::All();
        return view('periodos.index',compact('periodosr','bar'));
        //return view('periodos.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('periodos.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

       \impotlx\periodos::create([
        	'periodo' => $request ['periodo'],
        	'fecha_inicio'=> $request ['fecha_inicio'],
        	'fecha_fin'=>$request ['fecha_fin'],
            'estatus'=>$request ['estatus'],

        	]);
              return redirect('/periodo')->with('message','store');
             //return 'aqui estoy';
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

     $periodosr = \impotlx\periodos::find($id);
        return view('periodos.edit',compact('periodosr'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
