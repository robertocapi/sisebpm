<?php

namespace impotlx\Http\Controllers;

use Illuminate\Http\Request;

class papelesControllers extends Controller
{
    //
}
