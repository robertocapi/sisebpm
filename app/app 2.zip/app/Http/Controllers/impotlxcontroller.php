<?php

namespace impotlx\Http\Controllers;

use Illuminate\Http\Request;

class impotlxcontroller extends Controller
{
    //
    public function  index(){
    	return "estoy en index";
    }
}
