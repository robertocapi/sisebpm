<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class papeles extends Model
{
    //
}
