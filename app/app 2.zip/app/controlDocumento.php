<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class controlDocumento extends Model
{
    //
}
