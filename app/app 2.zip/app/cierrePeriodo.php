<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class cierrePeriodo extends Model
{
    //
}
