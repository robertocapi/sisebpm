<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class estatus extends Model
{
    //
       protected $table='estatus';
     protected $fillable = ['nombre'];
}
