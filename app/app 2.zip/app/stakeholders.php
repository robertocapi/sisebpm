<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class stakeholders extends Model
{
    //
    protected $table='stakeholders';
}
