<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class grupos extends Model
{
    //
      protected $table='grupos';
     protected $fillable = ['nombre', 'id_carrerra', 'periodo', 'dia','turno'];
    
}
