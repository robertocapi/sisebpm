<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class pagos extends Model
{
    //
 
               
    protected $table='pagos';
     protected $fillable = ['id_alumno', 'id_conceptopago','monto','fecha','realizadopor','observaciones','estatus'];
}
