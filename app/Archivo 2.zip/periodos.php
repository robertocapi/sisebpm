<?php

namespace impotlx;

use Illuminate\Database\Eloquent\Model;

class periodos extends Model
{
    //
     protected $table='periodos';
     protected $fillable = ['periodo', 'fecha_inicio', 'fecha_fin','estatus'];

  

}
