<?php

namespace impotlx\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    //
}
