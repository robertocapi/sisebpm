@extends('layout.principal')
@section('content')

<h1>Editar usuario: {{$periodosr->periodo}}</h1>


                   <div class="panel">
                                <h3 class="panel-heading">Basic Form</h3>
                                <div class="panel-body">
    {!! Form::model($periodosr, ['action' =>['periodoController@update',$periodosr->id],'method'=>'PATCH'])!!}
                              <div class="form-group label-floating">

                                  <label class="control-label">Nombre Periodo</label>
                                              {{ Form::text('periodo', null, ['class' => 'form-control']) }}
                                        </div>

                                        <div class="form-group label-floating">

                                  <label class="control-label">Estatus</label>
                                              {{ Form::text('estatus', null, ['class' => 'form-control']) }}
                                        </div>



                                        {!!Form::submit('Modificar',['class'=> 'btn btn-primary btn-outline']);!!}
                             {!! Form::close() !!}



                                </div>
                            </div>

@stop
