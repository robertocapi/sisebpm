@extends('layout.principal')
@section('content')




                   <div class="panel">
                                <h3 class="panel-heading">Capturar Pago</h3>
                                <div class="panel-body">
                                 {!! Form::open(['route' =>'pagos.store','method'=>'POST'])!!}
                      
<div class="form-group label-floating">
                                            <label class="control-label">Alumno</label>
                                             {!!Form::select('id_alumno',$alumnosr, null, ['placeholder' => 'Elige una Opción...']);!!}
                                             
                                        </div>

                                        <div class="form-group label-floating">
                                            <label class="control-label">Concepto de pago</label>
                                             {!!Form::select('id_conceptopago',$conceptopagor, null, ['placeholder' => 'Elige una Opción...']);!!}
                                             
                                        </div>
     


                                       
   <div class="form-group label-floating">
                                             {!!Form::label('Programa academico', 'Programa academico', ['class' => 'control-label']);!!}
                                              {{ Form::text('realizadopor', null, ['class' => 'form-control']) }}
                                        </div>

     <div class="form-group label-floating">
                                             {!!Form::label('Descuento', 'Descuento', ['class' => 'control-label']);!!}
                                              {{ Form::text('observaciones', null, ['class' => 'form-control']) }}
                                        </div>

                                          <div class="form-group label-floating">
                                             {!!Form::label('Beca', 'Beca', ['class' => 'control-label']);!!}
                                              {{ Form::text('observaciones', null, ['class' => 'form-control']) }}
                                        </div>
                                        
                               
     {{ Form::hidden ('realizadopor',Auth::user()->id, ['class' => 'form-control']) }}

                                        
                                     
                                        
                                        {!!Form::submit('Registrar',['class'=> 'btn btn-primary btn-outline']);!!}
                             {!! Form::close() !!}
                                </div>
                            </div>
                   
                






@stop

